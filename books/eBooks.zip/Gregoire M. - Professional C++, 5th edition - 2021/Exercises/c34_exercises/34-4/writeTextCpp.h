#ifdef __cplusplus
extern "C" {
#endif

	void writeTextFromCpp(const char* text);

#ifdef __cplusplus
} // matches extern "C"
#endif
