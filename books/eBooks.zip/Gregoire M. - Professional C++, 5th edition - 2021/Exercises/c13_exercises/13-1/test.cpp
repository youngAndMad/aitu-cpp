import person;

using namespace std;

int main()
{
	Person person{ "John", "Doe" };
	person.output();
}
