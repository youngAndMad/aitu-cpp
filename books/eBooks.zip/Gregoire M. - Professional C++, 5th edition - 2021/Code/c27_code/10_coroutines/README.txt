The generator.cpp file requires Microsoft Visual C++ 2019 or later.
You also have to specify the /std:c++latest compiler option.