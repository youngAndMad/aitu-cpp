Compile each of the files in this directory separately.
