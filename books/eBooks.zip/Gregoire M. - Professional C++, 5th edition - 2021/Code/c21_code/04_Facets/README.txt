Compile each of the source files in this directory separately.

02_codecvt.cpp might crash with Visual C++ 2019.