Some compilers might give you warnings or errors when compiling MemoryErrors.cpp.
If your compiler does compile the code, it will most likely crash before
execution can finish.