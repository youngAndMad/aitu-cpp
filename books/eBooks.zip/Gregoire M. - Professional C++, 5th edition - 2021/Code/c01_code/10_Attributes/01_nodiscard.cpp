[[nodiscard]] int func()
{
	return 42;
}

int main()
{
	func();
}
