import <iostream>;

using namespace std;

int main()
{
	cout.put('a');
}
