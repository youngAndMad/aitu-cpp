Unless otherwise noted, include all .cpp files in a subdirectory in your
project.
