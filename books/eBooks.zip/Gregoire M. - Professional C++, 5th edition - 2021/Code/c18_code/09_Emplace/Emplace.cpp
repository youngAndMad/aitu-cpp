import <vector>;
import <string>;

using namespace std;

int main()
{
	vector<string> vec;

	vec.emplace_back(5, 'a');
}
