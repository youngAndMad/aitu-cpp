class Demo
{
public:
	static int x;
};

int Demo::x{ 3 };
int y{ 4 };


int main()
{
}
