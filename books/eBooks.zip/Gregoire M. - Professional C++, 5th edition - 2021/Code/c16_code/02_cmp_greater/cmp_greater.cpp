import <iostream>;
import <utility>;

using namespace std;

int main()
{
	cout << (-1 > 0u) << endl;
	cout << cmp_greater(-1, 0u) << endl;
}
