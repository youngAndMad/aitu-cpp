#include <stdio.h>

int main()
{
	int class = 1; // Compiles in C, not C++
	printf("class is %d\n", class);
}
